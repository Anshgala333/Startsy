import Ionicons from '@expo/vector-icons/Ionicons';

export default Back = ()=>{
    return(
        <Ionicons name="arrow-back-circle-outline" size={50} color="#00DE62" />

    )
}