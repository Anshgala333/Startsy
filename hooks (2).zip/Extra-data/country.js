export default country1 = [
    { label: "10th", value: "10TH" },
    { label: "12th", value: "12th" },
    { label: "Graduate", value: "Graduate" },
    { label: "Post-Graduate", value: "Post-Graduate" },
    { label: "P.H.D", value: "P.H.D" },


]